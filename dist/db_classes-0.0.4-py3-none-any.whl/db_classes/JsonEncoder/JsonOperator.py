from abc import ABC


class JSONOperator(ABC):
    pass
