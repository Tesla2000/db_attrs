from dataclasses import dataclass

from .DbClass import DbClass


@dataclass
class DbClassLiteral(DbClass):
    pass
